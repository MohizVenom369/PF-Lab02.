#include <stdio.h>
int main (){
float radius=7.5;
float pi=3.14159;
float Diameter=2*radius;
float Circumference=2*pi*radius;
float Area=pi*radius*radius;
printf("================ CIRCLE GEOMETRY REPORT ================\n");
printf("Calculated Radius:\t\t\t%.3f\n",radius);
printf("Calculated Circumference:\t%.3f\n",Circumference);
printf("Calculated Diameter:\t\t%.3f\n",Diameter);
printf("Calculated Area:\t\t\t%.3f\n",Area);
printf("========================================================");
return 0;
}