#include<stdio.h>
int main ()
{
    float PF_Marks = 88.0 ;
    int PF_CredHrs = 3;
    float CAGeometry_Marks = 76.5 ;
    int CAGeometry_CredHrs = 3;
    float AP_Marks = 82.0 ;
    int AP_CredHrs = 2;

    double Total_Weighted_score = (PF_Marks * PF_CredHrs) + (CAGeometry_Marks * CAGeometry_CredHrs ) + (AP_Marks * AP_CredHrs );
    int Total_CredHrs = PF_CredHrs + CAGeometry_CredHrs + AP_CredHrs;
    double Weighted_Aver_Percentage = Total_Weighted_score / Total_CredHrs;

    printf("=============== SEMESTER ACADEMIC REPORT ======================\n");
    printf("Course \t\t\t Credit Hours \t\t\t Obtained Marks \n");
    printf("---------------------------------------------------------------\n");
    printf("Programming Fund\t\t\t %d\t\t\t\t %.2f\n",PF_CredHrs ,PF_Marks);
    printf("Calculus\t\t\t\t\t %d\t\t\t\t%.2f\n",CAGeometry_CredHrs,CAGeometry_Marks);
    printf("Applied Physics\t\t\t\t%d \t\t\t\t %.2f\n" , AP_CredHrs, AP_Marks);
    printf("---------------------------------------------------------------\n");
    printf("Total Credits :\t %d \t\t Weighted Average: %.2f%% \n" , Total_CredHrs, Weighted_Aver_Percentage);
    printf("==============================================================\n");

    return 0;
}