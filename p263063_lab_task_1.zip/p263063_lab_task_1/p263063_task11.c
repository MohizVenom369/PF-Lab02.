#include<stdio.h>
int main ()
{
int teaQuant = 3 ;
float teaUnitPrice = 60.00;
int samosaQuant = 4;
float SamosaUnitPrice = 40.50;
int chickenrollQuant = 2;
float chickenrollUnitPrice = 120.00;
float teaSubTotal = teaQuant * teaUnitPrice;
float samosaSubTotal = samosaQuant * SamosaUnitPrice;
float chickenSubTotal =  chickenrollQuant * chickenrollUnitPrice ;
float BillSubtotal = teaSubTotal + samosaSubTotal + chickenSubTotal;
float GeneralSaleTax = BillSubtotal * 0.16;
float finalPayableAmount = BillSubtotal + GeneralSaleTax;
printf("===================== FAST CAFERTRIA RECEIPT ===========================\n");
printf("Item \t\t\t Qty \t\t\t Unit Price (PKR) \t\t\t Subtotal (PKR)\n");
printf("------------------------------------------------------------------------\n");
printf("Tea \t\t\t %d \t\t\t\t %.2f \t\t\t\t\t\t %.2f\n" , teaQuant , teaUnitPrice , teaSubTotal);
printf("Samosa \t\t\t %d \t\t\t\t %.2f \t\t\t\t\t\t %.2f\n" , samosaQuant , SamosaUnitPrice , samosaSubTotal);
printf("Chicken Roll \t%d   \t\t\t %.2f     \t\t\t\t %.2f\n" , chickenrollQuant , chickenrollUnitPrice , chickenSubTotal);
printf("------------------------------------------------------------------------\n");
printf("Subtotal :\t\t\t\t\t\t\t\t\t\t\t\tPKR %.2f\n" , BillSubtotal);
printf("GST(16%%) :\t\t\t\t\t\t\t\t\t\t\t\tPKR %.2f\n" , GeneralSaleTax);
printf("------------------------------------------------------------------------\n");
printf("Grand Total :\t\t\t\t\t\t\t\t\t\t\tPKR %.2f \n" , finalPayableAmount);
printf("===================== THANK YOU FOR YOUR VISIT===========================\n");
return 0;
}