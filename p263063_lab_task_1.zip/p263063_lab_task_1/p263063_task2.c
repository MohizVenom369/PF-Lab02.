#include <stdio.h>
int main() {
printf("===========================================================\n");    printf("\t\t FAST-NUCES STUDENT PROFILE CARD\n");
printf("===========================================================\n");    
printf("Batch Year:\t\t\t2026\n ");
printf("Section:\t\t\tA\n");
printf("Test Score:\t\t\t82.75\n");
printf("Semester Fee:\t\tPKR 148500.50\n");
printf("Motto:\t\t\t\t\"Small daily steps lead to big success\"\n");
printf("===========================================================\n");
return 0;
}