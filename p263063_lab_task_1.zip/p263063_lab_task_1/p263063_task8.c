#include <stdio.h>
int main (){
double principal = 250000.00; //(PKR)
float rate = 8.5; //(8.5%)
int time = 3; //(Years)
double I = (principal*rate*time)/100.0;
double A = principal+IA/(time*12.0);
double Monthly Installment=A/(time*12.0)
printf("================ BANK LOAN INTEREST SUMMARY ================\n");
printf("Principal Amount:\t\tPKR%.2lf\n",principal);
printf("Annual Interest Rate:\t\t%.2f\n",rate);
printf("Loan Duration:\t\t%d\n",time);
printf("------------------------------------------------------------\n");
printf("Total Accrued Interest:\t\tPKR %.2lf\n",I);
printf("Total Payable Amount:\t\tPKR %.2lf\n",A);
printf("Monthly Installment:\t\tPKR %.2lf\n",Monthly Installment);
printf("============================================================\n");
return 0;
}