#include<stdio.h>
int main ()
{
    double basic_salary = 85000.00;
    float HRA = 0.20 * basic_salary;
    float Medical_Allowance = 0.10 * basic_salary;
    double Gross_Salary = basic_salary + HRA + Medical_Allowance;
    float incometax_deduction = 0.05 * Gross_Salary;
    double Net_Salary = Gross_Salary - incometax_deduction;

    printf("=================== MONTHLY SALARY SLIP =========================\n"); 
    printf("Basic Salary : \t\t\t\t\t PKR %.2f\n" , basic_salary);
    printf("House Rent Allowance : \t\t\t PKR %.2f\n" , HRA);
    printf("Medical Allowance : \t\t\t PKR %.2f\n" , Medical_Allowance);
    printf("-----------------------------------------------------------------\n");
    printf("Gross Salary :\t\t\t\t\tPKR %.2f\n" ,Gross_Salary );
    printf("Tax Deduction:\t\t\t\t\tPKR %.2f\n" ,incometax_deduction );
    printf("------------------------------------------------------------------\n");
    printf("Net Payable Salary :\t\t\tPKR %.2f\n" ,Net_Salary);
    printf("==================================================================\n"); 

}