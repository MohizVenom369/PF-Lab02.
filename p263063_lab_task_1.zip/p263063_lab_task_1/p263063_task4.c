#include <stdio.h>
int main (){
char a='M';
int b=42;
float c=3.141590;
double d=98.765432;
printf("Type Name\t\tVariable Value\t\tSize in Memory\n");
printf("---------------------------------------------------------\n");
printf("char\t\t\t'%c'\t\t\t\t\t%zu byte(s)\n",a,sizeof(a));
printf("int\t\t\t\t42\t\t\t\t\t%zu byte(s)\n",sizeof(b));
printf("float\t\t\t%f\t\t\t%zu byte(s)\n",c,sizeof(c));
printf("double\t\t\t%f\t\t\t%zu byte(s)\n",d,sizeof(d));
("---------------------------------------------------------\n");
return 0;
}