#include <stdio.h>
int main (){
float Celsius=37.5;
float Fahrenheit=(Celsius*9.0/5.0)+32.0;
float Kelvin=Celsius+273.15;
printf("================ TEMPERATURE CONVERSION =================\n");
printf("Temperature in Celsius:\t\t%.2f°C\n", Celsius);
printf("Temperature in Fahrenheit:\t%.2f°F\n", Fahrenheit );
printf("Temperature in Kelvin:\t\t%.2fK\n", Kelvin);
printf("=========================================================\n");
return 0;
}